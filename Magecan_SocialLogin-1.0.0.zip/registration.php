<?php
/**
 * Copyright © Magecan, Inc. All rights reserved.
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Magecan_SocialLogin',
    __DIR__
);
